# 说明
账号信息显示、刷新贴吧列表功能要求 Cookies 必须有 ptoken, 建议从 [http://api.kk.hydd.cc](http://api.kk.hydd.cc) 绑定。

PHP 版本必须大于 **5.3**，支持 **PHP7**
