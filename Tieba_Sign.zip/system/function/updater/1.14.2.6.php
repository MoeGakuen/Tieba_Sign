<?php
if(!defined('IN_KKFRAME')) exit('Access Denied');
saveSetting('version', '1.14.4.12');
showmessage('成功更新到 1.14.4.12！', './');
?>